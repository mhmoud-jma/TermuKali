#!/data/data/com.termux/files/usr/bin/bash

# Tool Installers
install_nmap() { pkg install -y nmap; }
install_whois() { pkg install -y whois; }
install_dnsutils() { pkg install -y dnsutils; }
install_nettools() { pkg install -y net-tools; }
install_whatweb() { pkg install -y whatweb; }
install_nikto() { pkg install -y nikto; }
install_wafw00f() { pip install wafw00f; }

install_harvester() {
    git clone https://github.com/laramies/theHarvester.git
    cd theHarvester && pip install -r requirements.txt && python3 setup.py install && cd ..
}

install_reconng() {
    git clone https://github.com/lanmaster53/recon-ng.git
    cd recon-ng && pip install -r REQUIREMENTS && cd ..
}

install_amass() { pkg install -y amass; }

install_sqlmap() {
    git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git
}

install_metasploit() {
    pkg install -y unstable-repo
    pkg install -y metasploit
}

install_hydra() { pkg install -y hydra; }
install_john() { pkg install -y john; }
install_crunch() { pkg install -y crunch; }

install_zphisher() {
    git clone https://github.com/htr-tech/zphisher.git
    chmod +x zphisher/zphisher.sh
}

install_hiddeneye() {
    git clone https://github.com/DarkSecDevelopers/HiddenEye.git
    cd HiddenEye && pip install -r requirements.txt && cd ..
}

install_socialfish() {
    git clone https://github.com/UndeadSec/SocialFish.git
    cd SocialFish && pip install -r requirements.txt || true && cd ..
}

install_tdrop() {
    git clone https://github.com/mhmoud-jma/T.DROP.git
}

# Install All Tools
install_all_tools() {
    install_nmap; install_whois; install_dnsutils; install_nettools
    install_whatweb; install_nikto; install_wafw00f
    install_harvester; install_reconng; install_amass
    install_sqlmap; install_metasploit; install_hydra
    install_john; install_crunch; install_zphisher
    install_hiddeneye; install_socialfish; install_tdrop

    echo -e "\n⭐ Thank you for using our toolkit! Support us on GitHub:"
    echo -e "🔗 https://github.com/mhmoud-jma/Install.kali"
}

# Install Specific Tool
install_by_name() {
    case "$1" in
        nmap) install_nmap ;;
        whois) install_whois ;;
        dnsutils) install_dnsutils ;;
        net-tools) install_nettools ;;
        whatweb) install_whatweb ;;
        nikto) install_nikto ;;
        wafw00f) install_wafw00f ;;
        theHarvester) install_harvester ;;
        recon-ng) install_reconng ;;
        amass) install_amass ;;
        sqlmap) install_sqlmap ;;
        metasploit) install_metasploit ;;
        hydra) install_hydra ;;
        john) install_john ;;
        crunch) install_crunch ;;
        zphisher) install_zphisher ;;
        HiddenEye) install_hiddeneye ;;
        SocialFish) install_socialfish ;;
        T.DROP) install_tdrop ;;
        *) echo "[!] Unknown tool: $1" ;;
    esac

    echo -e "\n⭐ Thank you for using the tool! Support us on GitHub:"
    echo -e "🔗 https://github.com/mhmoud-jma/Install.kali"
}

# Main Execution Logic
if [ "$1" == "all" ]; then
    install_all_tools
    exit
elif [ "$1" == "list" ]; then
    echo -e "nmap\nwhois\ndnsutils\nnet-tools\nwhatweb\nnikto\nwafw00f\ntheHarvester\nrecon-ng\namass\nsqlmap\nmetasploit\nhydra\njohn\ncrunch\nzphisher\nHiddenEye\nSocialFish\nT.DROP"
    exit
elif [ -n "$1" ]; then
    install_by_name "$1"
    exit
else
    echo "[!] Usage: $0 [tool-name | all | list]"
fi
