#!/data/data/com.termux/files/usr/bin/bash

INSTALL_SCRIPT="./kali.sh"
TOOLS_SCRIPT="./tools/install-tools.sh"

install_kali() {
    echo "[+] Starting Kali Linux installation..."
    bash "$INSTALL_SCRIPT"
}

install_tools() {
    echo -e "\n🛠️  Select installation mode:"
    echo "1) Install all tools"
    echo "2) Install a specific tool"
    echo "3) Back"
    read -p "Choose [1-3]: " mode

    case "$mode" in
        1)
            echo "[+] Installing all tools..."
            bash "$TOOLS_SCRIPT" all
            ;;
        2)
            echo -e "\n[+] Select a tool from the list:"
            tools_list=(
                "nmap" "whois" "dnsutils" "net-tools"
                "whatweb" "nikto" "wafw00f"
                "theHarvester" "recon-ng" "amass"
                "sqlmap" "metasploit" "hydra"
                "john" "crunch" "zphisher"
                "HiddenEye" "SocialFish"
                "Back"
            )
            select tool in "${tools_list[@]}"; do
                if [[ "$tool" == "Back" ]]; then break
                elif [ -n "$tool" ]; then
                    echo "[+] Installing tool: $tool"
                    bash "$TOOLS_SCRIPT" "$tool"
                    break
                else echo "[!] Invalid option."; fi
            done
            ;;
        3) return ;;
        *) echo "[!] Invalid option." ;;
    esac
}

list_tools() {
    echo -e "\n🧾 Available tools for installation:"
    bash "$TOOLS_SCRIPT" list
}

uninstall_kali() {
    echo -e "\n[!] Are you sure you want to uninstall Kali Linux? [y/N]"
    read confirm
    if [[ "$confirm" == "y" || "$confirm" == "Y" ]]; then
        rm -rf kali-fs kali-binds start-kali.sh
        echo "[+] Kali Linux has been removed from Termux."
    else
        echo "[*] Operation cancelled."
    fi
}

rate_project() {
    echo -e "\n📦 Thank you for supporting the project!"
    echo "Opening the GitHub project page in your browser..."
    termux-open-url "https://github.com/mhmoud-jma/Install.kali"
}

while true; do
    echo -e "\n╔════════════════════════════════════╗"
    echo "║       Kali Linux Installer Menu    ║"
    echo "╠════════════════════════════════════╣"
    echo "║ 1) Install Kali Linux              ║"
    echo "║ 2) Install Tools                   ║"
    echo "║ 3) List Available Tools            ║"
    echo "║ 4) Uninstall Kali Linux            ║"
    echo "║ 5) Exit                            ║"
    echo "║ 6) ⭐ Rate the project on GitHub    ║"
    echo "╚════════════════════════════════════╝"
    read -p "Select an option [1-6]: " choice

    case $choice in
        1) install_kali ;;
        2) install_tools ;;
        3) list_tools ;;
        4) uninstall_kali ;;
        5) echo "Goodbye 👋" && exit ;;
        6) rate_project ;;
        *) echo "[!] Invalid choice." ;;
    esac
done
