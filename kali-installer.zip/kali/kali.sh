#!/data/data/com.termux/files/usr/bin/bash
folder=kali-fs
if [ -d "$folder" ]; then
        first=1
        echo "skipping downloading"
fi
tarball="kali-rootfs.tar.xz"
if [ "$first" != 1 ];then
    if [ ! -f $tarball ]; then
        echo "Download Rootfs..."
        wget "https://example.com/kali-rootfs.tar.xz" -O $tarball
    fi
    mkdir -p "$folder"
    cd "$folder"
    proot --link2symlink tar -xJf ../$tarball ||:
    cd ..
fi
echo "[✓] تم التثبيت، استخدم ./start-kali.sh لتشغيل Kali"
echo -e "\n🌟 هل أعجبك السكربت؟ ساعدنا على الانتشار!"
echo -e "⭐ https://github.com/username/project"
